

var xmlDocument;
var longInDone;
var nomeLogIn;

loadDoc();


function getDateToday() {
 	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
    	dd = '0'+dd
	} 

	if(mm<10) {
    	mm = '0'+mm
	} 

	today = dd + '/' + mm + '/' + yyyy;

	return today;

}

function updateSugestoes(){
	var nome, sugestao, data, txt, html;

	printerTable();

	nome = document.getElementById("input_nome").value;
	sugestao = document.getElementById("input_Sugestao").value;
	data = getDateToday();
	txt = "";



	txt =  "<tr class='tr_sugestoesCorpo'><td class='td_sugestoesCorpo'><div class='jumbotron'><p class = 'p_sugestoesExpostas'>Gostei muito do arroz de distoAHAHAHA, muito bom e recomendo!<br><br>By Pedro Rodrigues on 28/02/2017</p></div></td><td class='td_sugestoesCorpo'><div class='jumbotron'><p class = 'p_sugestoesExpostas'>Nunca tinha experimentado este restaurante, mas confirmo o que me disseram, muito bom mesmo!<br><br>By Fátima Portas on 01/03/2017</p></div></td></tr>";

	html = document.getElementById("tbody_sugestoes").innerHTML;

	txt = txt + html;
	
	document.getElementById("tbody_sugestoes").innerHTML = txt;	
}

function printerTable() {
	var nLines, nCols, nLines, body, firstLine, localLine, lastLine,txt, bodyHtml, nome, sugestao, data;

	body = document.getElementById("tbody_sugestoes");
	nCols = document.getElementById("tbody_sugestoes").getElementsByTagName("tr")[0].getElementsByTagName("td").length;
	firstLine = document.getElementById("tbody_sugestoes").getElementsByTagName("tr")[0].getElementsByTagName("td");
	nLines = document.getElementById("tbody_sugestoes").getElementsByTagName("tr").length;
	lastLine = document.getElementById("tbody_sugestoes").getElementsByTagName("tr")[nLines - 1];
	txt = "";

	data = getDateToday();
	nome = document.getElementById("input_nome").value;
	sugestao = document.getElementById("input_Sugestao").value;


	if(nome != "" && sugestao != "")
	{
		if(nCols == 1)
		{
			localLine = document.getElementById("tbody_sugestoes").getElementsByTagName("tr")[0];
			txt = "<td class='td_sugestoesCorpo'><div class='jumbotron'><p class = 'p_sugestoesExpostas'>" + sugestao + "<br><br>By " + nome + " on " + data + "</p></div></td>";
			txt = txt + localLine.innerHTML;
			document.getElementById("tbody_sugestoes").getElementsByTagName("tr")[0].innerHTML = txt;	
		}
		else
		{
			document.getElementById("tbody_sugestoes").getElementsByTagName("tr")[nLines - 1].remove();
			txt = "<tr class='tr_sugestoesCorpo'><td class='td_sugestoesCorpo'><div class='jumbotron'><p class = 'p_sugestoesExpostas'>" + sugestao + "<br><br>By " + nome + " on " + data + "</p></div></td></tr>";
			document.getElementById("tbody_sugestoes").innerHTML = txt + body.innerHTML;
		}

		document.getElementById("input_nome").value = "";
		document.getElementById("input_Sugestao").value = "";
		document.getElementById("div_alertaSucesso").style.display = "block";
		document.getElementById("div_alertaErro").style.display = "none";		
	}
	else
	{
		document.getElementById("div_alertaErro").style.display = "block";
		document.getElementById("div_alertaSucesso").style.display = "none";
	}

}


function loadDoc(){
	var xhttp = new XMLHttpRequest();
  	var xmlDoc;

  	xhttp.onreadystatechange = function() {

    if (this.readyState == 4 && this.status == 200) {
      	xmlDoc = this.responseXML;
      	xmlDocument = xmlDoc;
      
      	loadSugestoes(xmlDoc);
     

    }
  };

	xhttp.open("GET", "sugestoes.xml", false);
  	xhttp.send();
}



function loadSugestoes(xmlDoc){

	var sugestoes, size, i, txt,allTexto, allAutor, allApelido, allData, firstLocalTexto, firstLocalAutor, firstLocalApelido, firstLocalData, scndLocalTexto, scndLocalAutor, scndLocalApelido, scndLocalData;

	
	sugestoes = xmlDoc.getElementsByTagName("sugestao");
	allTexto = xmlDoc.getElementsByTagName("texto");
	allAutor = xmlDoc.getElementsByTagName("autor");
	allApelido = xmlDoc.getElementsByTagName("apelido");
	allData = xmlDoc.getElementsByTagName("data");
	txt = "";
	size = sugestoes.length;


	for (i = 0; i < size; i++) 
	{

		if(i % 2 == 1)
		{
			firstLocalTexto = allTexto[i-1].childNodes[0].nodeValue;
			firstLocalAutor = allAutor[i-1].childNodes[0].nodeValue;
			firstLocalApelido = allApelido[i-1].childNodes[0].nodeValue;
			firstLocalData = allData[i-1].childNodes[0].nodeValue;

			scndLocalTexto = allTexto[i].childNodes[0].nodeValue;
			scndLocalAutor = allAutor[i].childNodes[0].nodeValue;
			scndLocalApelido = allApelido[i].childNodes[0].nodeValue;
			scndLocalData = allData[i].childNodes[0].nodeValue;

			txt = txt + "<tr class='tr_sugestoesCorpo'><td class='td_sugestoesCorpo'><div class='jumbotron'><p class = 'p_sugestoesExpostas'>" + firstLocalTexto + "<br><br>By " + firstLocalAutor + " " + firstLocalApelido + " on " + firstLocalData + "</p></div></td><td class='td_sugestoesCorpo'><div class='jumbotron'><p class = 'p_sugestoesExpostas'>" + scndLocalTexto + "<br><br>By " + scndLocalAutor + " " + scndLocalApelido + " on " + scndLocalData + "</p></div></td></tr>";
		}
	
		document.getElementById("tbody_sugestoes").innerHTML = txt;
	};

}


function btnEventLogIn(){
	var nome, password, body, txt;

	nome = document.getElementById("input_userNameLogIn").value;
	password = document.getElementById("input_passwordLogIn").value;
	body = document.getElementById("tbody_logIn");
	txt = "";

	longInDone = false;

	if(nome != "" && password != "")
	{
		txt = "<tr id ='tr_firstLineUserNamePassword'><td><p id='p_bemVindoUser'>Bem vindo, administrador</p></td><td><button id = 'btn_sair' type='button' class='btn btn-default'>Sair</button></td></tr>";
		document.getElementById("tbody_logIn").innerHTML = txt;
		longInDone = true;      
		nomeLogIn = nome;       
	}


}


function btnEventMesas(){

	var tbody, inputContent, campoValorAtual;

	inputContent = document.getElementById("input_numeroDeMesas").value;


	if(inputContent != "" && inputContent >= 0)
	{
		tbody = document.getElementById("tbody_mesasLivres");

		document.getElementById("div_alertaSucesso_mesas").style.display = "block";
		document.getElementById("div_alertaErro_mesas").style.display = "none";

		document.getElementById("td_numeroMesas").innerHTML = inputContent;
		document.getElementById("input_numeroDeMesas").value = "";
		

	}
	else
	{

		document.getElementById("div_alertaSucesso_mesas").style.display = "none";
		document.getElementById("div_alertaErro_mesas").style.display = "block";
		document.getElementById("input_numeroDeMesas").value = "";
	}

}


function btnEventConsultarMesasLivres(){
	
	if(longInDone == true)
	{
		window.open("mesasComLogin.html", "_self", false);
	}
	else
	{
		window.open("mesasSemLogin.html", "_self", false);
	}

}


























